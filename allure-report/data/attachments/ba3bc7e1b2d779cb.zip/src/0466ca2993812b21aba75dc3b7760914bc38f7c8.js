export class LoginPage{

    constructor(page)
    {
       this.page=page;

       this.userNameField= page.getByPlaceholder('Enter Email');
       this.passwordField =page.getByPlaceholder('Enter Password')
       this.loginButton=page.getByText('Sign in',{exact:true})
       this.newUserSignUpLink=page.getByRole('link',{name:'New user? Signup'});
       this.errorMessage=page.locator('.errorMessage');

    }

   async loginToApplication(username,password)
    {
       await  this.userNameField.fill(username);
       await this.passwordField.fill(password);
       await this.loginButton.click();
    }

    async clickOnNewUserSignUpLink()
    {
      await this.newUserSignUpLink().click();
    }
    async getErrorMessage()
    {
      return await this.errorMessage.textContent();

    }
}
